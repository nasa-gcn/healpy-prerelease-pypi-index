#!/bin/sh

./sharp_testsuite acctest

